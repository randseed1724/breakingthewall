Game: Braking the Wall

This game is intelectual property of Alejandro Jimenez Dominguez,


Copyright Notice:
All image and sprites that are not being attributed bellow belong to my authorship or are public domain images and Creative Commons.

Attribution Notice: 

Thank you to IronHack's TA Nick and special thanks to Kaysser, who tough me how to structure my files and helped me a lot with his advice.

Pixel bricks: ecstaticSalamander

Layout Author:  bevouliin.com *I modified original layout to my game convinience*
PickAxe: bevouliin.com

Music: "A Journey Awaits" by Pierre Bondoerffer (@pbondoer)


