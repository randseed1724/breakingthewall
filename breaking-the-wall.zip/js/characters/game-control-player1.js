

    function GameKeyPlayer1(){
    }



  GameKeyPlayer1.prototype.controlPlayer1 = function() {

// movement
    var direction = 1 ;

    var start = $("#grid"+ direction);
    var before = start;
    start.addClass( "trump" );  //Inicial Position
    var move = $("#grid"+ direction);

    var keyPressed = false;
    var lastEvent;
    var speed1 = 100;
    var speed2 = 200;
    var speed3 = 300;
    var speedCounter = 1;
    var lockChile = 0;



        $(document).on("keydown", function(event) {
//HERE LAST EVENT
          if (lastEvent && lastEvent.keyCode == event.keyCode) {
                 return;
             }
             lastEvent = event;



        var x = event.keyCode;
        if (x == 65 || x == 68 || x == 83 || x == 87) {
          before.removeClass('trump');
          before.removeClass('trump-right');
          before.removeClass('trump-left');
          before.removeClass('trump-brick');
          before.removeClass('trump-brick-2');
          before.removeClass('trump-brick-3');
          before.removeClass('trump-jump');
          before.removeClass("t-money");
        }

//obstacle 1 girl

        if (move.hasClass("inLove") === true) {
          return;
        }


//right key

        if (event.keyCode == 68 && ! keyPressed) {
          if (direction >= 65) {
            move.addClass("trump");
            if (speedCounter === 2) {
            move.addClass("t-money");
            }
            return;
          }
            if (direction < 65) {
              move.removeClass('trump');
              move.removeClass('trump-right');
              move.removeClass('trump-left');
              move.removeClass('trump-brick');
              move.removeClass('trump-brick-2');
              move.removeClass('trump-brick-3');
              move.removeClass('trump-jump');
              move.removeClass("t-money");

            keyPressed = true;
            direction += 9;
            move = $("#grid"+ direction);
            move.addClass("trump-right");


            setTimeout(function() {
            move.addClass("trump");
            // move.removeClass("trump-right");
            if (speedCounter === 2) {
            move.addClass("t-money");
            }

            if (move.hasClass("money") === true ) {
              move.addClass("mexican-hot");
              move.removeClass("money");
              move.removeClass("m-right");
              move.removeClass("mexican");
              speedCounter = 2;

              if (speedCounter === 2) {
                 speed1 = 50;
                 speed2 = 100;
                 speed3 = 150;

                setTimeout(function() {
                   speed1 = 100;
                   speed2 = 200;
                   speed3 = 300;
                   speedCounter = 1;
                   move.removeClass("mexican-hot");
                   move.addClass("mexican");

                }, 6000);
              }
            }


            before = move;
            keyPressed = false;
          }, 500);
          }
          }

//left key

        if (event.keyCode == 65 && ! keyPressed) {

          if (direction < 2 ) {
            move.addClass("trump");
            if (speedCounter === 2) {
            move.addClass("t-money");
            }
            return;
          }
            if (direction > 2) {
              move.removeClass('trump');
              move.removeClass('trump-right');
              move.removeClass('trump-left');
              move.removeClass('trump-brick');
              move.removeClass('trump-brick-2');
              move.removeClass('trump-brick-3');
              move.removeClass('trump-jump');
              move.removeClass("t-money");

            keyPressed = true;
            direction -= 9;
            move = $("#grid"+ direction);
            move.addClass("trump-left");


            setTimeout(function() {
            move.addClass("trump");
            if (speedCounter === 2) {
            move.addClass("t-money");
            }

            if (move.hasClass("money") === true ) {
              move.addClass("mexican-hot");
              move.removeClass("money");
              move.removeClass("trump-left");
              move.removeClass("trump");
              speedCounter = 2;

            if (speedCounter === 2) {
               speed1 = 50;
               speed2 = 100;
               speed3 = 150;

              setTimeout(function() {
                 speed1 = 100;
                 speed2 = 200;
                 speed3 = 300;
                 speedCounter = 1;
                 move.removeClass("t-money");
                 move.addClass("trump");

              }, 6000);
            }
          }

            before = move;
            keyPressed = false;

          }, 500);
          }
        }


//key 87 jump

        if (event.keyCode == 87 && !keyPressed) {

            keyPressed = true;

            move.removeClass("trump");

            direction -= 1;
            move = $("#grid"+ direction);
            move.addClass("trump-jump");
            move.removeClass("trump");
            move.removeClass("t-money");


            // }


            setTimeout(function() {
            move.removeClass("trump-jump");
            move.removeClass("trump");

            // move.removeClass("trump-right");
            direction += 1;
            move = $("#grid"+ direction);
            move.addClass("trump");

            if (speedCounter === 2) {
            move.addClass("t-money");
            }

            before = move;
            keyPressed = false;
          }, 800);
}

//Dropping Bricks
// key down


      if (event.keyCode == 83 && ! keyPressed) {
        keyPressed = true;
        move.removeClass("trump");
        if (speedCounter === 2) {
        move.addClass("t-money");
        }
        move.addClass("trump-brick");

        setTimeout(function() { move.removeClass("trump-brick");
        move.addClass( "trump-brick-2" );
      }, speed1);

      console.log("speed1",speed1);


        setTimeout(function() { move.removeClass("trump-brick-2");
        move.addClass( "trump-brick-3" );
      }, speed2);
      console.log("speed2",speed2);


        setTimeout(function() { move.removeClass("trump-brick-3");
       move.addClass( "trump" );
       if (speedCounter === 2) {
         move.addClass("t-money");
       }
       move.nextAll(':hidden:first').show();
       move.prev().prev().detach();
       keyPressed = false;
     }, speed3);
      }
    });

//POWER 1

  $('#btt').on("click", function(event) {
    var lastEvent;

  $(document).on("keydown", function(event) {
    if (lastEvent && lastEvent.keyCode == event.keyCode) {
           return;
       }
       lastEvent = event;

  ra = Math.floor(Math.random() * 100);


  var lock = false;

  if (lockChile < 4 && event.keyCode == 38 && !lock && ra >= 50   ) {
  lock = true;
  lockChile ++;
  console.log("Second lockChile",lockChile);

  console.log("ra",ra);
  var grids = [$("#grid1"),
   $("#grid10"), $("#grid19"),
   $("#grid28"), $("#grid37"),
   $("#grid46"), $("#grid55"),
   $("#grid64"), $("#grid73")];


   randomPlace = Math.floor(Math.random() * 9);

  console.log("randomPlace",randomPlace);

   if (grids[randomPlace].attr('id') == move.attr('id')) {
     return;
   }
    grids[randomPlace].addClass("money");
    before = move;
    lock = false;
  }
    lastEvent = null;
  });
  });

  $(document).on("keyup", function(event) {
    lastEvent = null;

           if (event.keyCode == 39 ) {
         move.addClass("mexican");
         if (speedCounter === 2) {
         move.addClass("mexican-hot");
         }

            if (event.keyCode == 37 ) {
          move.addClass("mexican");
          if (speedCounter === 2) {
          move.addClass("mexican-hot");
          }
    }

  }
  });
  };
