Breaking the Wall
...or building it

Call a friend and choose your character. Depending on your selection you will have to build or distroy the wall. Accomplish your task and win!

How to play?

1st Player
Key S: Build
Key W: Jump
Key A: Move Left
Key D: Move Right

2nd Player
Key Up: Destroy
Key Down: Hide
Key Left: Move Left
Key Right: Move Right






Copyright Notice:
This game is intelectual property of Alejandro Jimenez Dominguez. All images and sprites that are not being attributed bellow belong to my authorship or are public domain images and/or under Creative Commons.



Attribution Notice: 

Thank you to IronHack's TA Nick and special thanks to Kaysser, who tough me how to structure my files and helped me with the function of movement.

Pixel bricks: ecstaticSalamander

Layout Author:  bevouliin.com *I modified original layout to my game convinience*
PickAxe: bevouliin.com

Music: "A Journey Awaits" by Pierre Bondoerffer (@pbondoer)

Click sound effect called "acept": David McKee (ViRiX) soundcloud.com/virix




