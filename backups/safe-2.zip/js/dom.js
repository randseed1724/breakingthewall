//Building Layout
$(document).ready(function(){


game.init();


});
